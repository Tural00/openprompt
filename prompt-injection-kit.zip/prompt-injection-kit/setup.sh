#!/bin/bash
# One-command setup for prompt-injection-kit
# Run once on a new machine: bash setup.sh

set -e

echo "=================================================="
echo "  Prompt Injection Kit — Setup"
echo "=================================================="

# 1. Python version check
PYTHON=$(command -v python3 || command -v python)
PY_VERSION=$($PYTHON --version 2>&1 | awk '{print $2}')
echo "[1/4] Python: $PY_VERSION"

MAJOR=$(echo $PY_VERSION | cut -d. -f1)
MINOR=$(echo $PY_VERSION | cut -d. -f2)
if [ "$MAJOR" -lt 3 ] || ([ "$MAJOR" -eq 3 ] && [ "$MINOR" -lt 9 ]); then
  echo "[ERROR] Python 3.9+ required (found $PY_VERSION)"
  exit 1
fi

# 2. Virtual environment
if [ ! -d ".venv" ]; then
  echo "[2/4] Creating virtual environment (.venv)..."
  $PYTHON -m venv .venv
else
  echo "[2/4] Virtual environment already exists."
fi

source .venv/bin/activate

# 3. Install dependencies
echo "[3/4] Installing Python dependencies..."
pip install --quiet --upgrade pip
pip install --quiet -r requirements.txt
echo "      Done."

# 4. Ollama check
echo "[4/4] Checking Ollama..."
if ! command -v ollama &> /dev/null; then
  echo ""
  echo "  [WARNING] Ollama is not installed."
  echo "  Install it from: https://ollama.com/download"
  echo "  Then run: ollama pull llama3"
  echo ""
else
  OLLAMA_VERSION=$(ollama --version 2>/dev/null || echo "unknown")
  echo "      Ollama found: $OLLAMA_VERSION"

  # Check if llama3 is pulled
  if ollama list 2>/dev/null | grep -q "llama3"; then
    echo "      llama3 model: ready"
  else
    echo "      Pulling llama3 model (this may take a few minutes)..."
    ollama pull llama3
  fi
fi

echo ""
echo "=================================================="
echo "  Setup complete."
echo ""
echo "  To run experiments:"
echo "    source .venv/bin/activate"
echo "    ollama serve &           # if not already running"
echo "    python run_all.py"
echo ""
echo "  Options:"
echo "    python run_all.py --data_num 100"
echo "    python run_all.py --attacks naive combine --defenses no sandwich"
echo "    python run_all.py --ollama_model llama3.1"
echo "    python run_all.py --analytics_only"
echo "=================================================="
