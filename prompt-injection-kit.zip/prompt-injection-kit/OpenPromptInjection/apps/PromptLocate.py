import numpy as np
import random
import re


def binary_search(segments, start, end, detector, prefix, str_cache):
    left_idx, right = start, end
    tot_cnt = 0
    while left_idx < right:
        mid = (left_idx + right) // 2
        if prefix == "":
            remaining_text = " ".join(segments[start:mid]) if start < mid else ""
        else:
            remaining_text = prefix + " " + " ".join(segments[start:mid]) if start < mid else prefix
        tot_cnt += 1
        if remaining_text not in str_cache:
            str_cache[remaining_text] = detector.detect(remaining_text)
        if str_cache[remaining_text]:
            right = mid
        else:
            left_idx = mid + 1
    return left_idx, tot_cnt


class PromptLocate:
    """Lazy-loads torch/spacy/transformers on first use."""

    def __init__(self, model_name_or_path, device="cpu"):
        self.model_name_or_path = model_name_or_path
        self.device = device
        self._initialized = False

    def _lazy_init(self):
        if self._initialized:
            return
        import torch
        import spacy
        from spacy.language import Language
        from transformers import AutoTokenizer, AutoModelForCausalLM
        from OpenPromptInjection.apps.DataSentinelDetector import DataSentinelDetector

        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name_or_path)
        self.model = AutoModelForCausalLM.from_pretrained(self.model_name_or_path).to(self.device)
        self.nlp = spacy.load("en_core_web_sm")
        self.detector = DataSentinelDetector(self.model, self.tokenizer, self.device)
        self._initialized = True

    def locate(self, text):
        self._lazy_init()
        doc = self.nlp(text)
        segments = [sent.text for sent in doc.sents]
        str_cache = {}
        idx, _ = binary_search(segments, 0, len(segments), self.detector, "", str_cache)
        return " ".join(segments[:idx])
