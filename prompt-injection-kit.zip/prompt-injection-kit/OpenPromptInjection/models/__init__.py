from .OllamaModel import OllamaModel


def create_model(config):
    provider = config["model_info"]["provider"].lower()

    if provider == "ollama":
        return OllamaModel(config)

    # Lazy-load heavy backends so their dependencies are not required
    if provider == "gpt" or provider == "gpt_azure":
        from .GPT import GPT, GPTAzure
        return GPTAzure(config) if provider == "gpt_azure" else GPT(config)
    elif provider == "palm2":
        from .PaLM2 import PaLM2
        return PaLM2(config)
    elif provider == "vicuna":
        from .Vicuna import Vicuna
        return Vicuna(config)
    elif provider == "llama":
        from .Llama import Llama
        return Llama(config)
    elif provider == "llama3":
        from .Llama3 import Llama3
        return Llama3(config)
    elif provider == "flan":
        from .Flan import Flan
        return Flan(config)
    elif provider == "internlm":
        from .Internlm import Internlm
        return Internlm(config)
    elif provider == "deepseek":
        from .DeepSeek import DeepSeekWrapper, DeepSeekR1DistillLLaMAWrapper, DeepSeekR1DistillQwenWrapper
        model_name = config["model_info"]["name"].lower()
        if "distill" in model_name:
            if "llama" in model_name:
                return DeepSeekR1DistillLLaMAWrapper(config)
            return DeepSeekR1DistillQwenWrapper(config)
        return DeepSeekWrapper(config)

    raise ValueError(f"Unknown provider: {provider}")


def create_qlora_model(config):
    provider = config["model_info"]["provider"].lower()
    if provider in ("mistral", "llama"):
        from .QLoraModel import QLoraModel
        return QLoraModel(config)
    elif provider == "llama3":
        from .Llama3 import Llama3
        return Llama3(config)
    raise ValueError(f"Unknown provider: {provider}")
